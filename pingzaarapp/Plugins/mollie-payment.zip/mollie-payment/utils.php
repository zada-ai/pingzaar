<?php
/**
 * Shared payment-gateway helpers.
 *
 * Every gateway in this repo verified that a payment *existed* but never that it
 * was the *right* payment: none compared the amount actually paid against the
 * amount owed, and two of them took the paid/unpaid decision straight from the
 * request. These helpers hold the checks that must happen identically in all of
 * them, so a gateway cannot quietly omit one.
 *
 * This file is duplicated into each plugin rather than shared: Zender loads
 * plugins standalone, so there is nowhere shared to put it without changing core.
 */

/**
 * Minor units for a currency, so money is compared as integers.
 *
 * Comparing floats directly ("10.00" == 10.0) is unreliable, and providers
 * report amounts in several shapes -- Stripe in cents, Mollie as a decimal
 * string, PayPal as a decimal string, Paystack in kobo.
 */
if(!function_exists("mpg_currency_exponent")):
function mpg_currency_exponent($currency)
{
    $currency = strtoupper(trim($currency));

    $zero = [
        "BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA",
        "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"
    ];

    $three = ["BHD", "JOD", "KWD", "OMR", "TND"];

    if(in_array($currency, $zero))
        return 0;

    if(in_array($currency, $three))
        return 3;

    return 2;
}
endif;

/**
 * Converts a decimal amount to integer minor units for the given currency.
 */
if(!function_exists("mpg_to_minor")):
function mpg_to_minor($amount, $currency)
{
    return (int) round(((float) $amount) * pow(10, mpg_currency_exponent($currency)));
}
endif;


/**
 * Refuses a payment that does not match the order, for providers reporting the amount
 * in minor units (Stripe, Paystack, Razorpay) so it is not converted twice.
 */
if(!function_exists("mpg_minor_matches")):
function mpg_minor_matches($paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency)
{
    if(strtoupper(trim($paidCurrency)) !== strtoupper(trim($expectedCurrency)))
        return false;

    $tolerance = mpg_currency_exponent($paidCurrency) > 0 ? 1 : 0;

    return ((int) $paidMinor) >= (((int) $expectedMinor) - $tolerance);
}
endif;

/**
 * What the order expected to be charged, honouring the USD conversion setting.
 *
 * Returns [amount, currency] so a caller cannot accidentally compare the
 * converted amount against the base currency.
 */
if(!function_exists("mpg_expected_charge")):
function mpg_expected_charge($item, $pluginData)
{
    $converts = isset($pluginData["currency_conversion"]) && $pluginData["currency_conversion"] == "true";

    return $converts
        ? [$item["data"]["converted_price"], "USD"]
        : [$item["data"]["original_price"], $item["data"]["base_currency"]];
}
endif;

/**
 * Fulfils a verified payment: records the transaction, extends the subscription
 * or adds credits, and sends the customer and admin mail.
 *
 * Every gateway shared this block by copy-paste. It is here so a fix lands once.
 *
 * The transaction insert is the replay guard. `transactions.txn` carries a
 * unique index, so a provider retrying a webhook it already delivered fails that
 * insert, and nothing is credited a second time. Providers retry aggressively,
 * and the previous guard -- deleting the order row -- was a race: two concurrent
 * deliveries could both read the order before either deleted it.
 *
 * @return string "fulfilled", "replay" (already handled -- ack it), "duplicate"
 *                (a second payment on one order) or "error" (record failed --
 *                do not ack, let the provider retry).
 */
if(!function_exists("mpg_expected_in")):
/**
 * What the order should have cost in a gateway's own fixed currency.
 *
 * Several gateways do not offer a USD-conversion toggle: they convert the order
 * from the system currency into their own settlement currency at checkout and
 * charge in that. Verifying such a payment against the system currency compares
 * two different currencies and rejects every legitimate payment, so the
 * comparison has to be made in the currency actually billed.
 */
function mpg_expected_in($ctx, $item, $gatewayCurrency)
{
    $gatewayCurrency = strtoupper(trim($gatewayCurrency));

    $amount = strtoupper(system_currency) === $gatewayCurrency
        ? $item["data"]["original_price"]
        : $ctx->titansys->convertBaseToTarget($item["data"]["original_price"], system_currency, $gatewayCurrency, $ctx->cache);

    return [$amount, $gatewayCurrency];
}
endif;

if(!function_exists("mpg_fulfil")):
function mpg_fulfil($ctx, $getItem, $item, $user, $txn, $provider, $paidCurrency)
{
    $isPackage = $item["type"] < 2;

    $transaction = $ctx->system->create("transactions", [
        "uid"      => $user["id"],
        "pid"      => $isPackage ? $item["data"]["package"]["id"] : 0,
        "type"     => $isPackage ? 1 : 2,
        "price"    => $isPackage ? $item["data"]["original_price"] : $item["data"]["credits"],
        // What was actually charged, not the system default -- these differ
        // whenever the USD conversion setting is on.
        "currency" => strtoupper($paidCurrency),
        "duration" => $isPackage ? $item["data"]["duration"] : 0,
        "provider" => $provider,
        "txn"      => $txn
    ]);

    if(!$transaction):
        // create() returns false for any failure, so the two cases have to be
        // told apart here. A txn that is already on file is the provider
        // retrying a delivery we handled -- benign, ack it. Anything else is a
        // real database failure, and acking that would tell the provider "done"
        // for a payment we never recorded.
        return mpg_txn_exists($ctx, $txn) ? "replay" : "error";
    endif;

    // Claim the order before crediting. The row itself is the claim token: the
    // delete is a single atomic statement, so of two concurrent deliveries
    // exactly one removes a row and wins.
    //
    // The unique txn index above already stops the same payment being applied
    // twice. This stops a *different* payment being applied to the same order,
    // which is reachable when a customer opens checkout on two gateways and
    // completes both -- two genuine payments, two distinct txns, one order.
    if(!mpg_claim($ctx, $getItem["id"])):
        // The money is recorded, so the transaction row above is the audit
        // trail and the customer is not silently short-changed, but crediting
        // a second time for one order would be wrong. Flag it for a refund.
        mpg_log_double($provider, $getItem["id"], $txn);
        return "duplicate";
    endif;

    if($isPackage):
        if($ctx->system->checkSubscription($user["id"]) > 0):
            $subscription  = $ctx->system->getSubscription(false, $user["id"]);
            $currentExpiry = strtotime($subscription["sub_date"]);
            $now           = time();
            $startFrom     = ($currentExpiry > $now) ? $currentExpiry : $now;
            $newExpiry     = date("Y-m-d H:i:s", strtotime("+{$item["data"]["duration"]} months", $startFrom));

            $ctx->system->update($subscription["sid"], $user["id"], "subscriptions", [
                "pid"  => $item["data"]["package"]["id"],
                "tid"  => $transaction,
                "date" => $newExpiry
            ]);
        else:
            $newExpiry = date("Y-m-d H:i:s", strtotime("+{$item["data"]["duration"]} months"));

            $ctx->system->create("subscriptions", [
                "uid"  => $user["id"],
                "pid"  => $item["data"]["package"]["id"],
                "tid"  => $transaction,
                "date" => $newExpiry
            ]);
        endif;

        $ctx->mail->send([
            "title" => system_site_name,
            "data"  => [
                "subject"      => mail_title(__("response_package_purchasedtitle")),
                "package"      => $item["data"]["package"],
                "subscription" => $ctx->system->getSubscription(false, $user["id"])
            ]
        ], $user["email"], "_mail/subscribe.tpl", $ctx->smarty);

        mpg_notify_admin($ctx, "admin_package_buy", $user, $provider, sprintf(
            "has bought <strong>%s</strong> package worth <strong>%s %s</strong>",
            $item["data"]["package"]["name"],
            $item["data"]["package"]["price"],
            system_currency
        ));
    else:
        $ctx->system->credits($user["id"], "increase", $item["data"]["credits"]);

        $ctx->mail->send([
            "title" => system_site_name,
            "data"  => [
                "subject" => mail_title(__("payment_webhook_paypalcreditsadded")),
                "credits" => $item["data"]["credits"]
            ]
        ], $user["email"], "_mail/credits.tpl", $ctx->smarty);

        mpg_notify_admin($ctx, "admin_credits_buy", $user, $provider, sprintf(
            "has bought <strong>%s</strong> credits",
            $item["data"]["credits"]
        ));
    endif;

    $ctx->cache->container("system.transactions");
    $ctx->cache->clear();

    return "fulfilled";
}
endif;

/**
 * Admin alert mail, when the trigger is enabled and an address is configured.
 */
if(!function_exists("mpg_notify_admin")):
function mpg_notify_admin($ctx, $trigger, $user, $provider, $what)
{
    if(empty(system_mailing_address))
        return;

    if(!in_array($trigger, explode(",", system_mailing_triggers)))
        return;

    $content = "<p>Hi there!</p><p>This is to inform you that <strong>{$user["email"]}</strong> "
             . "{$what} via <strong>" . ucfirst($provider) . "</strong>.</p>";

    $ctx->mail->send([
        "title" => system_site_name,
        "data"  => [
            "subject" => mail_title("Admin Alert Message from " . system_site_name . "!"),
            "content" => $content
        ]
    ], system_mailing_address, "_mail/default.tpl", $ctx->smarty);
}
endif;

/**
 * Mail sent when a payment came back not-paid.
 */
if(!function_exists("mpg_notify_failed")):
function mpg_notify_failed($ctx, $user, $txn)
{
    $ctx->mail->send([
        "title" => system_site_name,
        "data"  => [
            "subject" => mail_title(__("payment_transact_failed")),
            "order"   => $txn ?: __("payment_webhook_unknowntn")
        ]
    ], $user["email"], "_mail/failed.tpl", $ctx->smarty);
}
endif;

/**
 * Records a payment whose amount did not match the order.
 *
 * This is the signal that someone is pointing a cheap payment at an expensive
 * order, so it must leave a trace rather than failing silently.
 */
if(!function_exists("mpg_log_mismatch")):
function mpg_log_mismatch($provider, $orderId, $paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency)
{
    @file_put_contents("system/storage/temporary/error.log", sprintf(
        "Payment Mismatch: %s order #%s paid %d %s, expected %d %s -- refused (%s)\n\n",
        $provider, $orderId, $paidMinor, strtoupper($paidCurrency),
        $expectedMinor, strtoupper($expectedCurrency), date("m/d/Y g:i A")
    ), FILE_APPEND);
}
endif;

/**
 * Is this transaction already on file?
 *
 * Used to tell a provider retry (benign) apart from a database failure (not),
 * because create() collapses both into `false`.
 */
if(!function_exists("mpg_txn_exists")):
function mpg_txn_exists($ctx, $txn)
{
    $row = $ctx->system->db->query_one("SELECT id FROM transactions WHERE txn = ?", [
        $txn
    ]);

    return !empty($row);
}
endif;

/**
 * Claims an order for fulfilment, atomically.
 *
 * Deleting the row by id is the claim: it is one statement, so concurrent
 * deliveries cannot both succeed, and the affected-row count says which one
 * won. Scoped by id rather than by uid -- deleting by uid would also remove any
 * other order the same customer had open.
 *
 * @return bool true when this caller claimed the order.
 */
if(!function_exists("mpg_claim")):
function mpg_claim($ctx, $orderId)
{
    $ctx->system->db->query("DELETE FROM orders WHERE id = ?", [
        $orderId
    ]);

    return $ctx->system->db->affected_rows() > 0;
}
endif;

/**
 * Records a second, genuinely-paid transaction landing on an order that was
 * already fulfilled.
 *
 * The customer has been charged twice and credited once, so this needs to reach
 * a human -- it is a refund, not a bug to swallow.
 */
if(!function_exists("mpg_log_double")):
function mpg_log_double($provider, $orderId, $txn)
{
    @file_put_contents("system/storage/temporary/error.log", sprintf(
        "Payment Double: %s order #%s already fulfilled, txn %s paid but not credited -- refund required (%s)\n\n",
        $provider, $orderId, $txn, date("m/d/Y g:i A")
    ), FILE_APPEND);
}
endif;

if(!function_exists("mpg_snapshot_charge")):
/**
 * Records what this gateway is about to charge, on the order itself.
 *
 * Verification used to recompute the expected amount independently at webhook
 * time, which meant the checkout and the verify path each derived the figure
 * from settings that could disagree -- or could have been changed by an admin
 * in between. Any divergence rejected a payment the customer had genuinely
 * made. Recording the figure once, where the charge is actually created, makes
 * the comparison exact by construction.
 *
 * Keyed by provider: a customer can open checkout on more than one gateway for
 * the same order, and each must verify against its own quote. A single shared
 * slot would let the second gateway overwrite the first, and paying the first
 * would then be refused for a currency it never quoted.
 *
 * Stored in minor units so the comparison is integer arithmetic. Written to the
 * order row, never to anything the browser can reach.
 */
function mpg_snapshot_charge($ctx, $orderId, $item, $provider, $minor, $currency)
{
    $item["charged"][$provider] = [
        "minor"    => (int) $minor,
        "currency" => strtoupper(trim($currency))
    ];

    $ctx->system->update($orderId, false, "orders", [
        "data" => json_encode($item)
    ]);

    return $item;
}
endif;

if(!function_exists("mpg_charged")):
/**
 * The figure this gateway quoted for this order, or false if none was recorded.
 *
 * False is expected for an order created before this version shipped -- a
 * customer mid-checkout during an upgrade -- and the caller falls back to
 * recomputing rather than refusing a real payment.
 *
 * @return array|false [minor, currency]
 */
function mpg_charged($item, $provider)
{
    if(!isset($item["charged"][$provider]["minor"], $item["charged"][$provider]["currency"]))
        return false;

    return [
        (int) $item["charged"][$provider]["minor"],
        strtoupper($item["charged"][$provider]["currency"])
    ];
}
endif;
