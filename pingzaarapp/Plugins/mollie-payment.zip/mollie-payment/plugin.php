<?php
/**
 * Mollie Payment Gateway
 */

require __DIR__ . "/utils.php";

return [
    "default" => function(&$request){
        if(!$this->session->has("logged"))
            $this->header->redirect(site_url("dashboard/auth"));

        $plugin = $this->system->getPlugin($request["name"], "directory");

        if(!$plugin)
            $this->pluginError(__("plugin_generic_unabletoprocess"));

        $pluginData = json_decode($plugin["data"], true);

        $getItem = $this->system->getOrder(logged_id, "uid");

        if(!$getItem)
            $this->pluginError(__("plugin_generic_unabletoprocess"));

        $item = json_decode($getItem["data"], true);

        $converts       = $pluginData["currency_conversion"] == "true";
        $chargeCurrency = $converts ? "USD" : $item["data"]["base_currency"];
        // Mollie takes a fixed two-decimal string, so that string is the charge.
        $chargeValue    = number_format(($converts ? $item["data"]["converted_price"] : $item["data"]["original_price"]), 2, '.', '');

        // Record it before creating the payment, so the webhook compares against
        // the exact figure that was sent.
        $item = mpg_snapshot_charge($this, $getItem["id"], $item, "mollie", mpg_to_minor($chargeValue, $chargeCurrency), $chargeCurrency);

        try {
            $mollie = new \Mollie\Api\MollieApiClient();
			$mollie->setApiKey($pluginData["apikey"]);

            // The webhook binds on this, so it must be the real order id.
            $paymentId = (string) $getItem["id"];

            if($item["type"] < 2):
                $payment = $mollie->payments->create([
                    "amount" => [
                        "currency" => $chargeCurrency,
                        "value" => $chargeValue
                    ],
                    "description" => $item["data"]["package"]["name"],
                    "redirectUrl" => site_url("plugin?name={$request["name"]}&hash={$item["data"]["user"]["hash"]}&action=success", true),
                    "webhookUrl"  => site_url("plugin?name={$request["name"]}&hash={$item["data"]["user"]["hash"]}&action=webhook&json=true", true),
                    "metadata" => [
                        "order_id" => $paymentId
                    ]
                ]);
            else:
                $payment = $mollie->payments->create([
                    "amount" => [
                        "currency" => $chargeCurrency,
                        "value" => $chargeValue
                    ],
                    "description" => __("widget_payment_creditslabel"),
                    "redirectUrl" => site_url("plugin?name={$request["name"]}&hash={$item["data"]["user"]["hash"]}&action=success", true),
                    "webhookUrl"  => site_url("plugin?name={$request["name"]}&hash={$item["data"]["user"]["hash"]}&action=webhook&json=true", true),
                    "metadata" => [
                        "order_id" => $paymentId
                    ]
                ]);
            endif;

            $this->header->redirect($payment->getCheckoutUrl());
        } catch (Exception $e) {
            $this->pluginError(___(__("plugin_generic_wentwrongerr"), [$e->getMessage()]));
        }
    },
    "success" => function(&$request){
        if(!$this->session->has("logged"))
            $this->header->redirect(site_url("dashboard/auth"));

        $vars = [
            "title" => __("title_payment_success"),
            "page" => "misc/payment",
            "data" => [
            	"message" => __("and_dash_pg_pay_line45")
            ]
        ];

        $this->smarty->assign($vars);
        $this->smarty->display(template . "/header.tpl");
        $this->smarty->display(__DIR__ . "/views/success.tpl");
        $this->smarty->display(template . "/footer.tpl");
    },
    "webhook" => function(&$request){
        if(!isset($request["id"], $request["hash"], $request["json"]))
            response(500);

        $plugin = $this->system->getPlugin($request["name"], "directory");

        if(!$plugin)
            response(500);

        $pluginData = json_decode($plugin["data"], true);

        // Authenticity: Mollie webhooks carry only an id, so the payment is
        // always re-fetched from Mollie rather than trusted from the request.
        try {
            $mollie = new \Mollie\Api\MollieApiClient();
            $mollie->setApiKey($pluginData["apikey"]);
            $payment = $mollie->payments->get($request["id"]);
        } catch (Exception $e) {
            response(500);
        }

        // Bind to the order this payment was created for.
        $orderId = isset($payment->metadata->order_id) ? $payment->metadata->order_id : false;

        if(!$orderId)
            response(400);

        $getItem = $this->system->getOrder($orderId, "id");

        if(!$getItem)
            response(404);

        $item = json_decode($getItem["data"], true);
        $user = $this->system->getUser($item["data"]["user"]["id"]);

        if(!$user)
            response(500);

        $txn = $payment->id;

        if(!$payment->isPaid() || $payment->hasRefunds() || $payment->hasChargebacks()):
            mpg_notify_failed($this, $user, $txn);
            response(200);
        endif;

        // Compare against the figure this gateway recorded when it created the
        // charge, rather than deriving a second one here. The fallback covers
        // orders placed before the snapshot existed -- a customer mid-checkout
        // across an upgrade -- because refusing those would take their money
        // and credit nothing.
        $charged = mpg_charged($item, "mollie");

        if($charged):
            list($expectedMinor, $expectedCurrency) = $charged;
        else:
            list($expectedAmount, $expectedCurrency) = mpg_expected_charge($item, $pluginData);
            $expectedMinor = mpg_to_minor($expectedAmount, $expectedCurrency);
        endif;

        $paidCurrency = $payment->amount->currency;
        $paidMinor    = mpg_to_minor($payment->amount->value, $paidCurrency);

        if(!mpg_minor_matches($paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency)):
            mpg_log_mismatch("mollie", $getItem["id"], $paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency);
            response(400);
        endif;

        $outcome = mpg_fulfil($this, $getItem, $item, $user, $txn, "mollie", $payment->amount->currency);

        // A failed record must not be acked: 200 tells the provider the payment
        // is handled and stops it retrying, so a transient database error would
        // lose the payment permanently. 500 asks it to deliver again.
        if($outcome === "error")
            response(500);

        response(200);
    }
];