<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 col-md-5 col-xl-4 my-5">
            <div class="text-center">

                <h6 class="text-uppercase text-muted mb-4">
                    {__("plugin_paymentpage_processingtitle")}
                </h6>

                <h1 class="display-4 mb-3">
                    PayPal
                </h1>

                <p class="text-muted mb-4">
                    {__("plugin_paymentpage_processingtagline")}
                </p>

                <div id="paypal-button-container"></div>

                <a href="{site_url("dashboard")}" class="btn btn-primary lift">
                    <i class="la la-arrow-circle-left"></i> {__("back_payment_page")}
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const paypalItem = {
        hash: "{$data.item.data.user.hash}",
        id: "{$data.order_id}",
        name: "{if $data.item.type < 2}{$data.item.data.package.name}{else}{__("widget_payment_creditslabel")}{/if}",
        description: "{if $data.item.type < 2}{$data.item.data.package.name}{else}{__("widget_payment_creditslabel")}{/if}",
        amount: {$data.charge.amount},
        currency: "{$data.charge.currency}",
    };
</script>
<script src="https://www.paypal.com/sdk/js?client-id={$data.plugin.client_id}&currency={$data.charge.currency}"></script>
<script src="{site_url("system/plugins/installables/paypal-payment/assets/paypal.js")}"></script>