(function ($) {
    "use strict";
    $(function () {
        $(document).on("pluginModalEvent", function (e) {
            if ($("[system-payments]").length && !$("[system-payments] .img-paypal").length) {
                $("[system-payments]").prepend(`
                <div class="col-md-6">
                    <a href="${site_url}/plugin?name=paypal-payment" class="btn btn-white btn-block mb-2 lift">
                        <img src="${site_url}/system/plugins/installables/paypal-payment/assets/btn.png" class="img-paypal">
                    </a>
                </div>
                `);
            }
        });
    });
})(jQuery);