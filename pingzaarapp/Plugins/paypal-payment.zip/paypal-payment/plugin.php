<?php
/**
 * PayPal Payment Gateway
 */

require __DIR__ . "/utils.php";

return [
    "default" => function(&$request){
        if(!$this->session->has("logged"))
            $this->header->redirect(site_url("dashboard/auth"));

        $plugin = $this->system->getPlugin($request["name"], "directory");

        if(!$plugin)
            $this->pluginError(__("plugin_generic_unabletoprocess"));

        $pluginData = json_decode($plugin["data"], true);

        $getItem = $this->system->getOrder(logged_id, "uid");

        if(!$getItem)
            $this->pluginError(__("plugin_generic_unabletoprocess"));

        $item = json_decode($getItem["data"], true);

        // Computed here rather than in the template. The view used to derive the
        // amount itself, which meant the figure the browser sent to PayPal and
        // the figure the webhook expected were two independent calculations off
        // two different settings -- the view read system_currency while the
        // webhook read base_currency. Deriving it once and recording it removes
        // any way for them to disagree.
        $converts       = isset($pluginData["currency_conversion"]) && $pluginData["currency_conversion"] == "true";
        $chargeCurrency = $converts ? "USD" : strtoupper($item["data"]["base_currency"]);
        $chargeAmount   = $converts ? $item["data"]["converted_price"] : $item["data"]["original_price"];

        $item = mpg_snapshot_charge($this, $getItem["id"], $item, "paypal", mpg_to_minor($chargeAmount, $chargeCurrency), $chargeCurrency);

        $vars = [
            "title" => __("plugin_paymentpage_processingtitle"),
            "page" => "misc/payment",
            "data" => [
                "plugin" => $pluginData,
                "item" => $item,
                // The webhook binds on this, so the button must send the real
                // order id rather than a throwaway uniqid.
                "order_id" => $getItem["id"],
                // The browser is told what to charge; it is never asked to work
                // it out. The webhook verifies against the same recorded figure,
                // so a tampered value here simply fails verification.
                "charge" => [
                    "amount" => $chargeAmount,
                    "currency" => $chargeCurrency
                ]
            ]
        ];
        
        $this->smarty->assign($vars);
        $this->smarty->display(template . "/header.tpl");
        $this->smarty->display(__DIR__ . "/views/default.tpl");
        $this->smarty->display(template . "/footer.tpl");
    },
    "success" => function(&$request){
        if(!$this->session->has("logged"))
            $this->header->redirect(site_url("dashboard/auth"));

        $vars = [
            "title" => __("title_payment_success"),
            "page" => "misc/payment",
            "data" => [
            	"message" => __("and_dash_pg_pay_line45")
            ]
        ];

        $this->smarty->assign($vars);
        $this->smarty->display(template . "/header.tpl");
        $this->smarty->display(__DIR__ . "/views/success.tpl");
        $this->smarty->display(template . "/footer.tpl");
    },
    "validate" => function(&$request){
        if(!isset($request["order_id"], $request["hash"]))
            response(500, __("plugin_generic_unabletoprocess"));

        $plugin = $this->system->getPlugin($request["name"], "directory");

        if(!$plugin)
            response(500, __("plugin_generic_unabletoprocess"));

        $pluginData = json_decode($plugin["data"], true);

        // The setting is "sandbox" (Enabled/Disabled), not "mode". Reading a key
        // that does not exist made this always falsy, so verification always hit
        // the sandbox API while the checkout button loaded the live SDK -- real
        // payments would never have been found.
        $paypalSandbox = isset($pluginData["sandbox"]) && $pluginData["sandbox"] == "true";

        $paypalCheckoutApi = $paypalSandbox
            ? "https://api-m.sandbox.paypal.com/v2/checkout"
            : "https://api-m.paypal.com/v2/checkout";

        $paypalAuthApi = $paypalSandbox
            ? "https://api-m.sandbox.paypal.com/v1/oauth2/token"
            : "https://api-m.paypal.com/v1/oauth2/token";

        // Authenticity: the order is re-fetched from PayPal, never trusted from
        // the request.
        try {
            $authResponse = $this->guzzle->post($paypalAuthApi, [
                "auth" => [$pluginData["client_id"], $pluginData["secret_key"]],
                "form_params" => ["grant_type" => "client_credentials"],
                "http_errors" => false
            ]);

            $authData = json_decode($authResponse->getBody()->getContents());

            $apiResponse = $this->guzzle->get("{$paypalCheckoutApi}/orders/{$request["order_id"]}", [
                "headers" => [
                    "Authorization" => "Bearer {$authData->access_token}",
                    "Content-Type" => "application/json"
                ],
                "http_errors" => false
            ]);

            $apiData = json_decode($apiResponse->getBody()->getContents(), true);
            $order = $apiResponse->getStatusCode() === 200 && !empty($apiData) ? $apiData : false;
        } catch (Exception $e) {
            response(500, ___(__("plugin_generic_wentwrongerr"), [$e->getMessage()]));
        }

        if(!$order || empty($order["id"]) || $order["status"] != "COMPLETED")
            response(400, __("plugin_generic_unabletoprocess"));

        $unit = isset($order["purchase_units"][0]) ? $order["purchase_units"][0] : [];
        $txn  = isset($unit["payments"]["captures"][0]["id"]) ? $unit["payments"]["captures"][0]["id"] : false;

        if(!$txn)
            response(400, __("plugin_generic_unabletoprocess"));

        // Bind to the order this payment was created for, carried in custom_id.
        $orderId = isset($unit["custom_id"]) ? $unit["custom_id"] : false;

        if(!$orderId)
            response(400, __("plugin_generic_unabletoprocess"));

        $getItem = $this->system->getOrder($orderId, "id");

        if(!$getItem)
            response(404, __("plugin_generic_unabletoprocess"));

        $item = json_decode($getItem["data"], true);
        $user = $this->system->getUser($item["data"]["user"]["id"]);

        if(!$user)
            response(500, __("plugin_generic_unabletoprocess"));

        // Compare against the figure this gateway recorded when it created the
        // charge, rather than deriving a second one here. The fallback covers
        // orders placed before the snapshot existed -- a customer mid-checkout
        // across an upgrade -- because refusing those would take their money
        // and credit nothing.
        $charged = mpg_charged($item, "paypal");

        if($charged):
            list($expectedMinor, $expectedCurrency) = $charged;
        else:
            list($expectedAmount, $expectedCurrency) = mpg_expected_charge($item, $pluginData);
            $expectedMinor = mpg_to_minor($expectedAmount, $expectedCurrency);
        endif;

        $paidAmount   = isset($unit["payments"]["captures"][0]["amount"]["value"]) ? $unit["payments"]["captures"][0]["amount"]["value"] : 0;
        $paidCurrency = isset($unit["payments"]["captures"][0]["amount"]["currency_code"]) ? $unit["payments"]["captures"][0]["amount"]["currency_code"] : "";
        $paidMinor    = mpg_to_minor($paidAmount, $paidCurrency);

        if(!mpg_minor_matches($paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency)):
            mpg_log_mismatch("paypal", $getItem["id"], $paidMinor, $paidCurrency, $expectedMinor, $expectedCurrency);
            response(400, __("plugin_generic_unabletoprocess"));
        endif;

        $outcome = mpg_fulfil($this, $getItem, $item, $user, $txn, "paypal", $paidCurrency);

        // A failed record must not be acked: 200 tells the provider the payment
        // is handled and stops it retrying, so a transient database error would
        // lose the payment permanently. 500 asks it to deliver again.
        if($outcome === "error")
            response(500);

        response(200);
    }
];